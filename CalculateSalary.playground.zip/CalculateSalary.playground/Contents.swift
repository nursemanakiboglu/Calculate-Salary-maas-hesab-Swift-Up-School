import UIKit

/*
   1 günde 8 saat çalışma
   Çalışma saat ücreti: 10 tl
   Mesai saat ücreti: 20 tl
   160 saat üzeri mesai
 */
class Program
{
    func hour(a:Int) -> Int
    {
        if (a<=160)
        {
             print(10 * a)
        }
        else
        {
            print(1600 + 20 * (a-160))
        }
        
            return 0
    }
    
}

let x = Program()
x.hour(a: 160)


